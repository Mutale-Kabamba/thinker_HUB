/* Interactive SCORM 1.2 Quiz Engine (MCQs + Theory Explainers) */
(function(window) {
  var timerInterval = null;
  var remainingSeconds = 45 * 60;
  var submitted = false;

  function renderQuiz(quizData) {
    var root = document.getElementById("quiz-root");
    if (!root) return;

    remainingSeconds = (quizData.time_limit_minutes || 45) * 60;
    var passMark = quizData.pass_percentage || 60;

    var htmlOut = '';
    htmlOut += '<div class="quiz-header-bar">';
    htmlOut += '  <div><strong>Questions:</strong> ' + quizData.questions.length + ' &nbsp;|&nbsp; <strong>Pass Mark:</strong> ' + passMark + '% &nbsp;|&nbsp; <strong>Publish:</strong> ' + (quizData.publish_at || '') + '</div>';
    htmlOut += '  <div class="timer-box">Time Left: <span id="quiz-timer">45:00</span></div>';
    htmlOut += '</div>';
    htmlOut += '<div id="score-banner" class="score-banner"></div>';

    quizData.questions.forEach(function(q, idx) {
      var qNum = q.sort_order || (idx + 1);
      var isMCQ = (q.type === "multiple_choice");
      htmlOut += '<div class="q-card" id="q-card-' + idx + '">';
      htmlOut += '  <div class="q-meta">Question ' + qNum + ' &bull; ' + (isMCQ ? 'Multiple Choice' : 'Theory / Explainer') + ' &bull; ' + (q.points || (isMCQ ? 2 : 4)) + ' Points</div>';
      htmlOut += '  <div class="q-title">' + escapeHtml(q.question) + '</div>';
      if (isMCQ && q.options) {
        q.options.forEach(function(opt, oIdx) {
          htmlOut += '<label class="opt-label"><input type="radio" name="q_' + idx + '" value="' + oIdx + '"> <span>' + escapeHtml(opt.option_text) + '</span></label>';
        });
      } else {
        htmlOut += '<textarea class="theory-input" id="theory_' + idx + '" placeholder="Write your clear explanation here (at least 15 words for full credit)..."></textarea>';
      }
      htmlOut += '  <div class="feedback-box" id="fb_' + idx + '"></div>';
      htmlOut += '</div>';
    });

    htmlOut += '<div class="completion-footer">';
    htmlOut += '  <button class="btn btn-primary" id="submit-quiz-btn" onclick="window.submitScormQuiz()">Submit Quiz &amp; Report Score to LMS</button>';
    htmlOut += '  <button class="btn btn-outline" onclick="location.reload()">Reset / Retake Quiz</button>';
    htmlOut += '</div>';

    root.innerHTML = htmlOut;

    // Start countdown timer
    updateTimerDisplay();
    timerInterval = setInterval(function() {
      if (submitted) return;
      remainingSeconds--;
      if (remainingSeconds <= 0) {
        remainingSeconds = 0;
        updateTimerDisplay();
        window.submitScormQuiz();
      } else {
        updateTimerDisplay();
      }
    }, 1000);

    window.submitScormQuiz = function() {
      if (submitted) return;
      submitted = true;
      clearInterval(timerInterval);

      var earned = 0;
      var possible = 0;
      var mcqCorrect = 0;
      var mcqTotal = 0;
      var theoryAnswered = 0;
      var theoryTotal = 0;

      quizData.questions.forEach(function(q, idx) {
        var pts = q.points || (q.type === "multiple_choice" ? 2 : 4);
        possible += pts;
        var card = document.getElementById("q-card-" + idx);
        var fb = document.getElementById("fb_" + idx);

        if (q.type === "multiple_choice") {
          mcqTotal++;
          var chosen = document.querySelector('input[name="q_' + idx + '"]:checked');
          var correctIdx = -1;
          var correctText = "";
          q.options.forEach(function(o, oi) {
            if (o.is_correct) { correctIdx = oi; correctText = o.option_text; }
          });
          if (chosen && Number(chosen.value) === correctIdx) {
            earned += pts;
            mcqCorrect++;
            card.classList.add("correct");
            fb.innerHTML = '<strong>&#10004; Correct (+' + pts + ' pts)</strong><br>' + escapeHtml(q.explanation || '');
          } else {
            card.classList.add("incorrect");
            fb.innerHTML = '<strong>&#10008; Incorrect (0/' + pts + ' pts)</strong> &mdash; Correct Answer: <em>' + escapeHtml(correctText) + '</em><br>' + escapeHtml(q.explanation || '');
          }
          fb.classList.add("show");
        } else {
          theoryTotal++;
          var ta = document.getElementById("theory_" + idx);
          var ans = ta ? ta.value.trim() : "";
          var words = ans ? ans.split(/\s+/).length : 0;
          if (words >= 8) {
            earned += pts;
            theoryAnswered++;
            card.classList.add("correct");
            fb.innerHTML = '<strong>&#10004; Response Recorded (+' + pts + ' pts — Instructor Review Recommended)</strong><br><strong>Official Model Answer:</strong> ' + escapeHtml(q.explanation || '');
          } else {
            card.classList.add("incorrect");
            fb.innerHTML = '<strong>&#9888; Incomplete Response (0/' + pts + ' pts — please write a complete explanation)</strong><br><strong>Official Model Answer:</strong> ' + escapeHtml(q.explanation || '');
          }
          fb.classList.add("show");
        }
      });

      var pct = possible > 0 ? Math.round((earned / possible) * 100) : 0;
      var passed = pct >= passMark;
      var banner = document.getElementById("score-banner");
      banner.className = "score-banner " + (passed ? "pass" : "fail");
      banner.innerHTML =
        '<h2 style="margin:0 0 6px;color:inherit;">' + (passed ? 'Congratulations! Quiz Passed' : 'Score Below Pass Mark (' + passMark + '%) — Please Review & Retake') + '</h2>' +
        '<p style="margin:0;"><strong>Final Score:</strong> ' + earned + ' / ' + possible + ' points (<strong>' + pct + '%</strong>) &nbsp;|&nbsp; ' +
        '<strong>MCQs Correct:</strong> ' + mcqCorrect + '/' + mcqTotal + ' &nbsp;|&nbsp; ' +
        '<strong>Theory Completed:</strong> ' + theoryAnswered + '/' + theoryTotal + '</p>';

      var btn = document.getElementById("submit-quiz-btn");
      if (btn) btn.disabled = true;

      if (window.SCORM) {
        window.SCORM.set("cmi.suspend_data", JSON.stringify({ score: pct, earned: earned, possible: possible, passed: passed }));
        window.SCORM.setComplete(passed ? "passed" : "failed", pct);
      }
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
  }

  function updateTimerDisplay() {
    var el = document.getElementById("quiz-timer");
    if (!el) return;
    var m = Math.floor(remainingSeconds / 60);
    var s = remainingSeconds % 60;
    el.textContent = (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s;
  }

  function escapeHtml(str) {
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  window.renderScormQuiz = renderQuiz;
})(window);
