/* SCORM 1.2 Runtime API Wrapper with Parent Shell Bridge & LocalStorage Fallback */
(function(window) {
  var API = null;
  var initialized = false;
  var startTime = new Date().getTime();
  var scoId = document.body ? (document.body.getAttribute("data-sco-id") || location.pathname) : location.pathname;

  function findAPI(win) {
    var attempts = 0;
    while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
      attempts++;
      if (attempts > 10) return null;
      win = win.parent;
    }
    return win.API;
  }

  function getAPI() {
    var theAPI = findAPI(window);
    if ((theAPI == null) && (window.opener != null) && (typeof(window.opener) != "undefined")) {
      theAPI = findAPI(window.opener);
    }
    return theAPI;
  }

  function formatTime(ms) {
    var totalSec = Math.floor(ms / 1000);
    var hrs = Math.floor(totalSec / 3600);
    var mins = Math.floor((totalSec % 3600) / 60);
    var secs = totalSec % 60;
    function pad(n) { return (n < 10 ? "0" : "") + n; }
    return pad(hrs) + ":" + pad(mins) + ":" + pad(secs);
  }

  var isChildFrame = (window.parent && window.parent !== window && typeof window.parent.onScoProgress === "function");

  if (window.parent && window.parent !== window && document.body) {
    document.body.classList.add("in-shell");
  }

  var SCORM = {
    isLMS: false,
    init: function() {
      if (initialized) return true;
      if (isChildFrame) {
        initialized = true;
        return true;
      }
      API = getAPI();
      if (API) {
        var res = API.LMSInitialize("");
        if (res === "true" || res === true) {
          initialized = true;
          this.isLMS = true;
          var status = this.get("cmi.core.lesson_status");
          if (!status || status === "not attempted") {
            this.set("cmi.core.lesson_status", "incomplete");
            this.commit();
          }
          return true;
        }
      }
      initialized = true;
      this.isLMS = false;
      return true;
    },
    get: function(key) {
      if (!isChildFrame && this.isLMS && API) {
        return API.LMSGetValue(key);
      }
      try { return localStorage.getItem("SCORM_" + scoId + "_" + key) || ""; } catch (e) { return ""; }
    },
    set: function(key, val) {
      if (!isChildFrame && this.isLMS && API) {
        return API.LMSSetValue(key, String(val));
      }
      try { localStorage.setItem("SCORM_" + scoId + "_" + key, String(val)); } catch (e) {}
      return "true";
    },
    commit: function() {
      if (!isChildFrame && this.isLMS && API) { API.LMSCommit(""); }
    },
    setComplete: function(status, rawScore) {
      status = status || "completed";
      this.set("cmi.core.lesson_status", status);
      if (typeof rawScore === "number") {
        this.set("cmi.core.score.min", "0");
        this.set("cmi.core.score.max", "100");
        this.set("cmi.core.score.raw", String(Math.round(rawScore)));
      }
      this.set("cmi.core.session_time", formatTime(new Date().getTime() - startTime));
      this.commit();
      this.updateStatusBadge(status, rawScore);
      if (isChildFrame) {
        window.parent.onScoProgress(scoId, status, typeof rawScore === "number" ? Math.round(rawScore) : null);
      }
    },
    updateStatusBadge: function(status, score) {
      var el = document.getElementById("scorm-status-badge");
      if (!el) return;
      if (status === "passed" || status === "completed") {
        el.className = "badge badge-done";
        el.textContent = (status === "passed" ? "PASSED" : "COMPLETED") + (typeof score === "number" ? " (" + Math.round(score) + "%)" : "");
      } else if (status === "failed") {
        el.className = "badge badge-fail";
        el.textContent = "FAILED (" + (typeof score === "number" ? Math.round(score) + "%" : "") + ")";
      } else {
        el.className = "badge badge-gold";
        el.textContent = "IN PROGRESS";
      }
    },
    finish: function() {
      if (!initialized) return;
      if (!isChildFrame) {
        this.set("cmi.core.session_time", formatTime(new Date().getTime() - startTime));
        this.commit();
        if (this.isLMS && API) { API.LMSFinish(""); }
      }
      initialized = false;
    }
  };

  window.SCORM = SCORM;
  window.addEventListener("load", function() {
    SCORM.init();
    var st = SCORM.get("cmi.core.lesson_status") || "incomplete";
    var sc = SCORM.get("cmi.core.score.raw");
    SCORM.updateStatusBadge(st, sc !== "" ? Number(sc) : undefined);
  });
  window.addEventListener("beforeunload", function() { SCORM.finish(); });
})(window);

function switchTab(tabId, btn) {
  document.querySelectorAll(".tab-panel").forEach(function(p) { p.classList.remove("active"); });
  document.querySelectorAll(".tab-btn").forEach(function(b) { b.classList.remove("active"); });
  var target = document.getElementById(tabId);
  if (target) target.classList.add("active");
  if (btn) btn.classList.add("active");
}
