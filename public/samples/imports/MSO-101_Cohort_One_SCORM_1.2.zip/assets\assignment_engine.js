/* Interactive SCORM 1.2 Assignment & Capstone Verification Engine */
function initChecklist(storageKey) {
  var boxes = document.querySelectorAll(".deliverable-chk");
  var notesEl = document.getElementById("learner-submission-notes");
  var saved = null;
  try {
    var raw = window.SCORM ? window.SCORM.get("cmi.suspend_data") : "";
    if (raw) saved = JSON.parse(raw);
  } catch (e) {}

  if (saved && saved.checks) {
    boxes.forEach(function(b, i) { b.checked = !!saved.checks[i]; });
  }
  if (saved && saved.notes && notesEl) {
    notesEl.value = saved.notes;
  }

  function saveState() {
    var checks = [];
    boxes.forEach(function(b) { checks.push(b.checked); });
    var payload = { checks: checks, notes: notesEl ? notesEl.value : "" };
    if (window.SCORM) {
      window.SCORM.set("cmi.suspend_data", JSON.stringify(payload));
      window.SCORM.commit();
    }
  }

  boxes.forEach(function(b) { b.addEventListener("change", saveState); });
  if (notesEl) notesEl.addEventListener("input", saveState);

  var completeBtn = document.getElementById("mark-asst-complete");
  if (completeBtn) {
    completeBtn.addEventListener("click", function() {
      var allChecked = true;
      boxes.forEach(function(b) { if (!b.checked) allChecked = false; });
      saveState();
      if (!allChecked) {
        alert("Please verify and tick all deliverable checklist items before marking this submission ready.");
        return;
      }
      if (window.SCORM) {
        window.SCORM.setComplete("completed", 100);
      }
      var msg = document.getElementById("asst-confirm-msg");
      if (msg) {
        msg.style.display = "block";
        msg.innerHTML = "<strong>&#10004; Marked Complete in LMS!</strong> Ensure you have also uploaded your final files to the think.er HUB Student Portal before the deadline.";
      }
    });
  }
}
